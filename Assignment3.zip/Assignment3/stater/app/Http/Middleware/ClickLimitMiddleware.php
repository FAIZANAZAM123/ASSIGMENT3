<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Session;

class ClickLimitMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    { $clicks = Session::get('register_clicks', 0);
        $lastClickTime = Session::get('last_register_click_time', null);
        $currentTime = time();
        $clickLimit = 3; // Maximum number of clicks allowed
        $timeLimit = 60; // Time limit in seconds

        if ($clicks >= $clickLimit && $currentTime - $lastClickTime < $timeLimit) {
            // User has exceeded the click limit within the time limit
            return redirect()->back()->with('error', 'You have exceeded the maximum number of register button clicks within one minute.');
        }
        if ($currentTime - $lastClickTime >= $timeLimit) {
            $clicks = 0;
        }

        $clicks++;
        Session::put('register_clicks', $clicks);
        Session::put('last_register_click_time', $currentTime);

        return $next($request);
    }
}
