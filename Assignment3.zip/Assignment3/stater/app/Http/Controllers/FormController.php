<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rules\ReCaptcha;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class FormController extends Controller
{
    /**
     * Display the registration form.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('Form');
    }

    /**
     * Store the registration data in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    
        public function store(Request $request)
        {

            if (Session::has('register_clicks_exceeded')) {
                $lastInsertedId = DB::table('students')->insertGetId([
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'password' => $request->input('password'),
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
        
                dispatch(new RollbackRegistration($lastInsertedId));
        
                return redirect()->back()->with('error', 'You have exceeded the maximum number of register button clicks within one minute.');
            }
            $request->validate([
                'name' => 'required',
                'email' => 'required|email|unique:students',
                'password' => 'required|confirmed',
                'g-recaptcha-response' => ['required', new ReCaptcha]
            ]);
        
            DB::table('students')->insert([
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'password' => $request->input('password'),
                'created_at' => now(),
                'updated_at' => now()
            ]);

            Session::put('rregistered', true);
            return redirect()->route('second.page');
        }
        public function show()
        {
            return view('Secondpage');
        }

        

        
       
    
}
