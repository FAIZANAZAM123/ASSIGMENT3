<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css" />
    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
    <div class="container">
        <h1>Register</h1>
        <div class="row ">
            <div class="col-10 offset-1 mt-5">

                
                    
                    <div class="card-body">
                   
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('Form.store')); ?>">
                            <?php echo csrf_field(); ?>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <strong>Firstname *</strong>
                                        <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e(old('name')); ?>">
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <strong>Email *</strong>
                                        <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <strong>Password *</strong>
                                        <input type="password" name="password" class="form-control" placeholder="Please enter your Password *">
                                        
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <strong>ConfirmPassword</strong>
                                        <input type="password" name="password_confirmation" class="form-control" placeholder="Rewrite Password">                                       
                                    </div>
                                </div>
                               
                            </div>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        
                                        <div class="g-recaptcha" data-sitekey="<?php echo e(env('GOOGLE_RECAPTCHA_KEY')); ?>"></div>
                                        <?php if($errors->has('g-recaptcha-response')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('g-recaptcha-response')); ?></span>
                                        <?php endif; ?>
                                    </div>  
                                </div>
                            </div>
                   
                            <div class="form-group">
                                <button class="btn btn-success btn-submit">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
           
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\New\Desktop\Assignment\stater\resources\views/Form.blade.php ENDPATH**/ ?>