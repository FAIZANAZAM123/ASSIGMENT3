<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\Storage;

class GenerateDummyData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'dummydata:generate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate random dummy data and create CSV files';

    /**
     * Execute the console command.
     */
    public function __construct()
    {
        parent::__construct();
    }
    public function handle()
    {
        $faker = Faker::create();
        $data = [];

        // Generate dummy data for table1
        for ($i = 0; $i < 10; $i++) {
            $data[] = [
                $faker->name,
                $faker->address,
                $faker->phoneNumber
            ];
        }
        $this->createCSV('table1.csv', $data);

        // Generate dummy data for table2
        $data = [];
        for ($i = 0; $i < 10; $i++) {
            $data[] = [
                $faker->word,
                $faker->sentence,
                $faker->boolean
            ];
        }
        $this->createCSV('table2.csv', $data);

        // Generate dummy data for table3
        $data = [];
        for ($i = 0; $i < 10; $i++) {
            $data[] = [
                $faker->email,
                $faker->date,
                $faker->randomNumber
            ];
        }
        $this->createCSV('table3.csv', $data);

        // Generate dummy data for table4
        $data = [];
        for ($i = 0; $i < 10; $i++) {
            $data[] = [
                $faker->colorName,
                $faker->country,
                $faker->city
            ];
        }
        $this->createCSV('table4.csv', $data);

        $this->info('Dummy data generated successfully!');
    }
    private function createCSV($filename, $data)
    {
        $file = fopen(storage_path('app/' . $filename), 'w');
        foreach ($data as $row) {
            fputcsv($file, $row);
        }
        fclose($file);
    }
}
