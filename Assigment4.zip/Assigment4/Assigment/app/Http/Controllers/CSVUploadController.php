<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Jobs\InsertDataIntoTable1;
use App\Jobs\InsertDataIntoTable2;
use App\Jobs\InsertDataIntoTable3;
use App\Jobs\InsertDataIntoTable4;

class CSVUploadController extends Controller
{
    public function upload()
{
    return view('Upload'); // Replace 'upload' with the name of your view file
}
    public function uploadTable1(Request $request)
    {
        $csvFiles = $request->file('csv_files');

        foreach ($csvFiles as $table => $file) {
           
            if ($file->getClientOriginalExtension() !== 'csv') {
                return back()->with('error', 'Only CSV files are allowed');
            }

            $path = $file->storeAs('csv', $file->getClientOriginalName());

            switch ($table) {
                case 'table1':
                    InsertDataIntoTable1::dispatch(storage_path('app/' . $path));
                    break;
                case 'table2':
                    InsertDataIntoTable2::dispatch(storage_path('app/' . $path));
                    break;
                case 'table3':
                    InsertDataIntoTable3::dispatch(storage_path('app/' . $path));
                    break;
                case 'table4':
                    InsertDataIntoTable4::dispatch(storage_path('app/' . $path));
                    break;
            }
        }

        


        return response()->json(['message' => 'CSV file uploaded and job dispatched successfully']);
    }

   
}
