<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class InsertDataIntoTable1 implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $csvData;

    /**
     * Create a new job instance.
     */
    public function __construct($csvData)
    {
        $this->csvData = $csvData;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
{
    $rows = array_map('str_getcsv', file($this->csvData));
    $header = array_shift($rows);

    $data = [];
    foreach ($rows as $row) {
        if (count($header) === count($row)) {
            $data[] = array_combine($header, $row);
            
        } else {
            // Log or handle the error when the number of keys and values doesn't match
            // For example, you can skip the row or perform some other action
            continue;
        }
    }

    DB::table('table1')->insert($data);
}
}
