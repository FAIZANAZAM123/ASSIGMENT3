<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .div{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-content: center;
            align-items: center;
            height:100vh;
        }
        .file1{
            display: flex;
            justify-content: space-between;
        
        }
        .file2{
            display: flex;
            justify-content: space-between;
        

        }
        .h
        {
            margin-right: 102px;
        }
        button{
            background:blueviolet;
            margin-top:10px; 
            height: 40px;
            width: 60px;
            border-radius: 7px;
            padding: 2px;
            color: white
        }
        button:hover{
            background: green;
            cursor: pointer;
        }
       input{
        height: 30px;
       }
        .gg{
            margin-top: 10px;
        }
    </style>
</head>
<body>
    @if(session('error'))
    <div>{{ session('error') }}</div>
    @endif

    <div class="div">
    <form action="{{ route('csv.upload.table1') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="file1">
            <label for="">Upload CSV 1(Table1):</label>
            <label class="h" for="">Upload CSV 2(Table2):</label>
        </div>
        <div class="file1">
        <input type="file" name="csv_files[table1]">
        <input type="file" name="csv_files[table2]">
    </div>
    <div class="gg">
        <div class="file2">
            <label for="">Upload CSV 3(Table3):</label>
            <label class='h' for="">Upload CSV 4(Table4):</label>
        </div>
        <div class="file2">
        <input type="file" name="csv_files[table3]">
        <input type="file" name="csv_files[table4]">
    </div>
    </div>
        <button type="submit">Upload</button>
    </form>
</div>
</body>
</html>
